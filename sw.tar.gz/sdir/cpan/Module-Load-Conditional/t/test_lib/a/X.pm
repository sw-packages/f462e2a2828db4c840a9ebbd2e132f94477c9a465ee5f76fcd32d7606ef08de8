package X;
use strict;

our $VERSION = '0.01';

1;
